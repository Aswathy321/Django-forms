from django.contrib import admin
from .models import primary
# Register your models here.
admin.site.register(primary)